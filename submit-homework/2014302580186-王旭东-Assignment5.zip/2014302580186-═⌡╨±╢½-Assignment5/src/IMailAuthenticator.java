import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
public class IMailAuthenticator extends Authenticator{
	private String username;
	private String password;
	private String mailname;
	private String sendname;
	
	public IMailAuthenticator(String username,String password){
		this.username=username;
		this.password=password;
	}
	String getSendname(){
		return sendname;
	}
	String getMailname(){
		return mailname;
	}
	String getUsername(){
		return username;
		}
	String getPassword(){
		return password;
	}
	public void setSendname(){
		this.sendname=sendname;
	}
	public void setUsername(String username){
		this.username=username;
	}
	
	public void setPassword(String password){
		this.password=password;
	}

	
	@Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username, password);
    }

}
