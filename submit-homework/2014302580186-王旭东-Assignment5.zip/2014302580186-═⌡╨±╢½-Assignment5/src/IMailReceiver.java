import javax.mail.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;
public class IMailReceiver {
	private final transient Properties pro=System.getProperties();
	private transient IMailAuthenticator authenticator;
	private transient Session ses;
	public IMailReceiver(final String pop,final String username,final String password){
		init (pop,username,password);
	}
private void init(String pop,String username,String password){
	pro.put("mail.store.protocol","imap");
	pro.put("mail.imap.host",pop);
	authenticator=new IMailAuthenticator(username,password);
	ses=Session.getInstance(pro,authenticator);
}
public void receive()throws MessagingException,IOException{
	//Folder folder=store.getFolder("inbox");
	int i=0;
	Store store=ses.getStore();
	store.connect();
	Folder folder=store.getFolder("inbox");
	folder.open(Folder.READ_ONLY);
	Message[] message=folder.getMessages(1,2);
	
	int MailCounts=message.length;
	for(i=0;i<MailCounts;i++){
		String subject=message[i].getSubject();
		String address=(message[i].getFrom()[0].toString());
		System.out.println("��"+(i+1)+"���ʼ���subject��"+subject);
		System.out.println("��"+(i+1)+"���ʼ���address��"+address);
		System.out.println("�Ƿ�򿪣�");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String input=br.readLine();
		if("yes".equalsIgnoreCase(input)){
			message[i].writeTo(System.out);
		}
		
	}
	folder.close(false);
	store.close();
}
}
