import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import java.io.IOException;
public class Main2014302580186 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IMaiSender wxds=new IMaiSender("smtp.sina.com","hjktest@sina.com","java123456");
		String recipient="wxdjavatest@sina.com";
		try{
			//wxds.init("smtp.sina.com","wxdjavatest@sina.com","wxd687095");
			wxds.send(recipient,"try","tryinformation");
			}catch(Exception e){
				e.printStackTrace();
			}
//IMailReceiver wxdr=new IMailReceiver("imap.sina.com","wxdjavatest@sina.com","wxd687095");
//try{
//wxdr.receive();
	
//}catch(MessagingException e){	e.printStackTrace();
//}catch(IOException e){
//	e.printStackTrace();
//}
	}

}
